﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeMovement : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        // -
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        // Hier had de box naar de cube moeten moven als de boolean van onTriggerEnter true zou zijn
    }

    void OnTriggerEnter(Collider other)
    {
        // Dit had een boolean kunnen zijn, zodat hij de fixedupdate aan zou roepen zolang als de cube in range is van de trigger van de box (boxcollider).
        // Hierbij zou een if-statement moeten zitten die checkt of het object wat in boxcollider zit wel de player is.
        Debug.Log("Cube heeft de boxcollider binnnengetreden");
        Vector3.MoveTowards(transform.position, other.transform.position, 1f);
    }
}
